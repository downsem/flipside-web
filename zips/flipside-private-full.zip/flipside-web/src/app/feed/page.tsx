import FeedPageClient from "./page.client";

export const revalidate = 0;

export default function FeedPage() {
  return <FeedPageClient />;
}
