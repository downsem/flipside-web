// src/app/prototype/rooms/new/page.tsx
import NewRoomClient from "./page.client";

export default function NewRoomPage() {
  return <NewRoomClient />;
}
