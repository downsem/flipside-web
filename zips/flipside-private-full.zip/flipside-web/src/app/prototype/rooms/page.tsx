// src/app/prototype/rooms/page.tsx
import RoomsClient from "./page.client";

export default function RoomsPage() {
  return <RoomsClient />;
}
