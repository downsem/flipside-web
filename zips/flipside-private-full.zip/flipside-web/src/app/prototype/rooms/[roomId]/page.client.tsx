// src/app/prototype/rooms/[roomId]/page.client.tsx
"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import clsx from "clsx";
import {
  addChatMessage,
  buildSolutionPrompt,
  getRoom,
  upsertRoom,
  type Room,
} from "@/prototype/rooms/store";

type Tab = "chat" | "solution" | "prompt";

export default function RoomClient({ roomId }: { roomId: string }) {
  const [room, setRoom] = useState<Room | null>(null);
  const [tab, setTab] = useState<Tab>("chat");
  const [name, setName] = useState("You");
  const [input, setInput] = useState("");

  useEffect(() => {
    setRoom(getRoom(roomId));
  }, [roomId]);

  function refresh() {
    setRoom(getRoom(roomId));
  }

  const prompt = useMemo(() => {
    if (!room) return "";
    return buildSolutionPrompt(room);
  }, [room]);

  if (!room) {
    return (
      <div className="min-h-screen bg-slate-50 px-6 py-10">
        <div className="max-w-3xl mx-auto rounded-3xl border border-slate-200 bg-white p-6">
          <div className="text-lg font-semibold text-slate-900">Room not found</div>
          <p className="mt-2 text-sm text-slate-600">
            This Room may have been cleared from local storage.
          </p>
          <div className="mt-4 flex gap-3">
            <Link href="/prototype/rooms" className="text-sm underline text-slate-700">
              Back to Rooms
            </Link>
            <Link href="/prototype/people-mode" className="text-sm underline text-slate-700">
              Build a deck
            </Link>
          </div>
        </div>
      </div>
    );
  }

  function send() {
    const trimmed = input.trim();
    if (!trimmed) return;
    addChatMessage(room.id, { authorName: name, content: trimmed });
    setInput("");
    refresh();
  }

  function setDraftSolution(text: string) {
    const next = { ...room };
    next.solution = {
      status: "draft",
      content: text,
      createdAt: Date.now(),
    };
    upsertRoom(next);
    refresh();
  }

  async function copyToClipboard(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      alert("Copied.");
    } catch {
      alert("Copy failed.");
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 px-6 py-8">
      <div className="max-w-4xl mx-auto space-y-4">
        <header className="flex items-start justify-between gap-4">
          <div>
            <div className="text-xs text-slate-500">Prototype · Room</div>
            <h1 className="text-2xl font-semibold text-slate-900">{room.title}</h1>
            <div className="mt-1 text-xs text-slate-500">
              Seed + chat are message-numbered for citations.
            </div>
          </div>
          <Link href="/prototype/rooms" className="text-sm underline text-slate-700">
            Back to Rooms
          </Link>
        </header>

        {/* Seed panel */}
        <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="text-base font-semibold text-slate-900">Seed (from People Mode deck)</div>
            <div className="text-xs text-slate-500">{room.messages.filter(m => m.kind==="seed").length} seed messages</div>
          </div>

          <div className="mt-4 space-y-3">
            {room.messages
              .filter((m) => m.kind === "seed")
              .map((m, idx) => (
                <div key={m.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <div>
                      <span className="font-medium text-slate-700">[{idx + 1}]</span>{" "}
                      Seed{m.lens ? ` (${m.lens})` : ""} — {m.authorName}
                    </div>
                  </div>
                  <div className="mt-2 text-sm text-slate-900 whitespace-pre-wrap">{m.content}</div>
                </div>
              ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="flex rounded-2xl border border-slate-200 bg-white overflow-hidden">
          {(["chat", "solution", "prompt"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={clsx(
                "px-4 py-2 text-sm flex-1",
                tab === t ? "bg-slate-100 font-medium" : "hover:bg-slate-50"
              )}
            >
              {t === "chat" ? "Chat" : t === "solution" ? "AI Solution (stub)" : "Prompt preview"}
            </button>
          ))}
        </div>

        {/* Chat */}
        {tab === "chat" && (
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-40 rounded-full border border-slate-200 px-3 py-2 text-sm"
                placeholder="Your name"
              />
              <div className="text-xs text-slate-500">
                (Prototype only — no auth yet)
              </div>
            </div>

            <div className="h-[380px] overflow-auto rounded-2xl border border-slate-200 bg-white">
              {room.messages.map((m, i) => (
                <div key={m.id} className="px-4 py-3 border-b last:border-0">
                  <div className="text-xs text-slate-500">
                    <span className="font-medium text-slate-700">[{i + 1}]</span>{" "}
                    {m.kind === "seed" ? `Seed${m.lens ? ` (${m.lens})` : ""}` : "Chat"} — {m.authorName}
                  </div>
                  <div className="mt-1 text-sm text-slate-900 whitespace-pre-wrap">{m.content}</div>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Write a message…"
                className="flex-1 rounded-2xl border border-slate-200 px-4 py-3 text-sm"
              />
              <button
                onClick={send}
                className="rounded-2xl bg-slate-900 px-5 py-3 text-sm font-medium text-white"
              >
                Send
              </button>
            </div>
          </div>
        )}

        {/* Solution (stub) */}
        {tab === "solution" && (
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div className="text-base font-semibold text-slate-900">Solution article</div>
              <div className="flex items-center gap-2">
                <button
                  disabled
                  className="rounded-full bg-slate-200 px-3 py-2 text-sm text-slate-500 cursor-not-allowed"
                  title="UI-only for now"
                >
                  Generate (coming soon)
                </button>
                <button
                  onClick={() => copyToClipboard(prompt)}
                  className="rounded-full border border-slate-200 bg-white px-3 py-2 text-sm"
                >
                  Copy prompt
                </button>
              </div>
            </div>

            <div className="text-sm text-slate-600">
              For now this is UI-only. You can tweak the draft manually to simulate iteration.
            </div>

            <textarea
              value={room.solution?.content ?? ""}
              onChange={(e) => setDraftSolution(e.target.value)}
              placeholder="(Draft solution will appear here once generation is wired.)"
              className="w-full min-h-[260px] rounded-2xl border border-slate-200 p-4 text-sm outline-none focus:ring-2 focus:ring-slate-200"
            />

            <div className="text-xs text-slate-500">
              When we wire “guts,” this field will be filled by the transcript-only generator and must cite message numbers.
            </div>
          </div>
        )}

        {/* Prompt preview */}
        {tab === "prompt" && (
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-base font-semibold text-slate-900">Prompt preview</div>
              <button
                onClick={() => copyToClipboard(prompt)}
                className="rounded-full border border-slate-200 bg-white px-3 py-2 text-sm"
              >
                Copy
              </button>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-800 whitespace-pre-wrap">
              {prompt}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
