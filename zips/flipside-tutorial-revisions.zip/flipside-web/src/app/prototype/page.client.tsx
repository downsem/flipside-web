"use client";

import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import type { TimelineId } from "@/theme/timelines";
import { TIMELINE_LIST } from "@/theme/timelines";
import { usePrototypeStore } from "@/prototype/people/store";
import { isTutorialActive, onTutorialChange } from "@/tutorial/mode";

const ORDER: TimelineId[] = ["calm", "bridge", "cynical", "opposite", "playful"];

function spec(t: TimelineId) {
  return TIMELINE_LIST.find((x) => x.id === t)!;
}

export default function PrototypeFeedClient() {
  const sp = useSearchParams();
  const justPublished = sp.get("published") === "1";
  const [tutorialActive, setTutorialActive] = useState(false);

  useEffect(() => {
    setTutorialActive(isTutorialActive());
    return onTutorialChange(() => setTutorialActive(isTutorialActive()));
  }, []);

  const { seedIfNeeded, peopleDecks, voteOnPost, addReplyToPost, currentUser } =
    usePrototypeStore();

  useEffect(() => {
    seedIfNeeded();
  }, [seedIfNeeded]);

  const decks = useMemo(() => {
    return [...peopleDecks].sort((a, b) => b.createdAt - a.createdAt);
  }, [peopleDecks]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center text-xs font-semibold">
            FS
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold tracking-tight">
              Prototype Feed
            </span>
            <span className="text-[10px] text-slate-500">
              People decks (AI not mocked here)
            </span>
          </div>
        </div>

        {!tutorialActive && (
          <div className="flex items-center gap-3">
          <Link
            href="/prototype/create"
            className="inline-flex items-center justify-center rounded-full bg-slate-900 px-4 py-2 text-xs font-medium text-white shadow-sm"
          >
            Add Flip
          </Link>

          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-600">
            <span>{currentUser.name}</span>
            <span className="text-slate-400">@{currentUser.handle}</span>
          </div>
        </div>
        )}
      </header>

      <main className="flex-1 px-4 py-6 max-w-2xl mx-auto w-full space-y-4">
        {justPublished && (
          <div className="mb-6 rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="text-base font-semibold text-slate-900">Deck published (tutorial)</div>
            <p className="mt-1 text-sm text-slate-600">
              Nice — your People Mode deck is now visible in the deck feed.
            </p>
            <div className="mt-4 flex flex-wrap gap-3">
              <Link
                href="/feed"
                className="inline-flex items-center justify-center rounded-full bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
              >
                Go to MVP Feed →
              </Link>
              <Link
                href="/tutorial"
                className="inline-flex items-center justify-center rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-900 hover:bg-slate-50"
              >
                Tutorial Home
              </Link>
            </div>
          </div>
        )}
        {decks.length === 0 && (
          <div className="rounded-3xl border border-slate-200 bg-white p-6">
            <div className="text-sm font-semibold text-slate-900">
              No People decks yet
            </div>
            <div className="mt-1 text-sm text-slate-600">
              Create one to start testing.
            </div>
            <Link
              href="/prototype/create"
              className="mt-4 inline-flex rounded-full bg-slate-900 px-4 py-2 text-xs font-medium text-white"
            >
              Create People Deck
            </Link>
          </div>
        )}

        {decks.map((deck) => (
          <div
            key={deck.id}
            className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex flex-col">
                <div className="text-sm font-semibold text-slate-900">
                  {deck.anchor.author.name}{" "}
                  <span className="text-slate-500 font-medium">
                    @{deck.anchor.author.handle}
                  </span>
                </div>
                <div className="text-xs text-slate-500">
                  Published {new Date(deck.createdAt).toLocaleString()}
                </div>
              </div>

              <div className="inline-flex items-center rounded-full border border-slate-200 bg-white px-3 py-1 text-xs">
                People
              </div>
            </div>

            {/* Anchor */}
            <div className="mt-4">
              <div className="text-xs text-slate-500 mb-2">Anchor</div>
              <CardBlock
                postId={deck.anchor.id}
                label="Anchor"
                icon="⚓"
                text={deck.anchor.text}
                onVote={voteOnPost}
                onReply={addReplyToPost}
              />
            </div>

            {/* Locked lenses (SwipeDeck-like blocks) */}
            <div className="mt-4 space-y-3">
              {ORDER.map((t) => {
                const s = spec(t);
                const p = deck.locked[t];
                return (
                  <CardBlock
                    key={t}
                    postId={p.id}
                    label={s.label}
                    icon={s.icon}
                    text={p.text}
                    by={`${p.author.name} @${p.author.handle}`}
                    onVote={voteOnPost}
                    onReply={addReplyToPost}
                  />
                );
              })}
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}

function CardBlock(props: {
  postId: string;
  label: string;
  icon: string;
  text: string;
  by?: string;
  onVote: (postId: string, value: 1 | -1) => void;
  onReply: (postId: string, text: string) => void;
}) {
  const { postId, label, icon, text, by, onVote, onReply } = props;

  const [replyText, setReplyText] = useState("");
  const [localVote, setLocalVote] = useState<-1 | 1 | null>(null);

  function voteBtnClass(isSelected: boolean) {
    return isSelected
      ? "px-3 py-1 rounded-full bg-slate-900 text-white"
      : "px-3 py-1 rounded-full border border-slate-300 text-slate-700 hover:bg-slate-50";
  }

  async function handleVote(value: 1 | -1) {
    const next = localVote === value ? null : value;
    setLocalVote(next);
    if (next === null) return;
    onVote(postId, next);
  }

  async function handleReplySubmit() {
    const trimmed = replyText.trim();
    if (!trimmed) return;
    onReply(postId, trimmed);
    setReplyText("");
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="inline-flex items-center gap-2 rounded-full bg-slate-50 px-3 py-1">
          <span className="text-[11px] font-medium text-slate-700">
            <span className="mr-1">{icon}</span>
            {label}
          </span>
        </div>
        {by && <div className="text-[11px] text-slate-500">{by}</div>}
      </div>

      <div className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-3 text-sm text-slate-900 whitespace-pre-wrap">
        {text}
      </div>

      <div className="flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => handleVote(1)}
            className={voteBtnClass(localVote === 1)}
            aria-pressed={localVote === 1}
          >
            👍
          </button>
          <button
            type="button"
            onClick={() => handleVote(-1)}
            className={voteBtnClass(localVote === -1)}
            aria-pressed={localVote === -1}
          >
            👎
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2 text-[11px]">
        <input
          type="text"
          value={replyText}
          onChange={(e) => setReplyText(e.target.value)}
          placeholder="Reply to this version…"
          className="flex-1 rounded-full border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-300"
        />
        <button
          type="button"
          onClick={handleReplySubmit}
          className="px-3 py-2 rounded-full bg-slate-800 text-white text-[11px]"
        >
          Reply
        </button>
      </div>
    </div>
  );
}