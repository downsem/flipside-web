import Link from "next/link";

export default function TutorialHomePage() {
  return (
    <div className="min-h-screen bg-slate-50 px-6 py-10">
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="space-y-2">
          <div className="text-xs font-semibold text-slate-500">Tutorial</div>
          <h1 className="text-3xl font-semibold text-slate-900">Learn Flipside hands-on</h1>
          <p className="text-sm text-slate-600">
            This tutorial lets you explore MVP, People Mode, and Backroom Mode in a guided, safe sandbox.
            Tutorial mode stays on until you click “Exit tutorial” in the top bar.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="text-base font-semibold text-slate-900">MVP</div>
            <p className="mt-2 text-sm text-slate-600">
              Explore the real MVP: Add Flip and the Feed.
            </p>
            <div className="mt-4 flex flex-col gap-2">
              <Link href="/" className="rounded-2xl bg-slate-900 px-4 py-2 text-sm font-medium text-white text-center">
                Go to MVP Add Flip →
              </Link>
              <Link href="/feed" className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-900 text-center">
                Go to MVP Feed →
              </Link>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="text-base font-semibold text-slate-900">People Mode</div>
            <p className="mt-2 text-sm text-slate-600">
              Build a People deck (5/5 matches), publish it, then start a Room.
            </p>
            <div className="mt-4 flex flex-col gap-2">
              <Link href="/prototype/create" className="rounded-2xl bg-slate-900 px-4 py-2 text-sm font-medium text-white text-center">
                Start People Mode tutorial →
              </Link>
              <Link href="/prototype" className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-900 text-center">
                View People decks →
              </Link>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="text-base font-semibold text-slate-900">Backroom Mode</div>
            <p className="mt-2 text-sm text-slate-600">
              Start a Room from a deck and generate a transcript-bound solution (UI stub).
            </p>
            <div className="mt-4 flex flex-col gap-2">
              <Link href="/prototype/rooms/new" className="rounded-2xl bg-slate-900 px-4 py-2 text-sm font-medium text-white text-center">
                Start Backroom tutorial →
              </Link>
              <Link href="/prototype/rooms" className="rounded-2xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-900 text-center">
                View Rooms →
              </Link>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="text-base font-semibold text-slate-900">Tip</div>
          <p className="mt-2 text-sm text-slate-600">
            If you end up on a page that feels “stuck,” use the tutorial top bar to jump back to Tutorial Home,
            MVP Add Flip, or MVP Feed.
          </p>
        </div>
      </div>
    </div>
  );
}
