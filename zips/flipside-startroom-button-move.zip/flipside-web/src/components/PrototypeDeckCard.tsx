"use client";

import { useMemo } from "react";
import Link from "next/link";
import { usePrototypeStore } from "@/prototype/people/store";
import type { PeopleDeck } from "@/prototype/people/types";
import PeopleDeckSwipe from "./PeopleDeckSwipe";

export default function PrototypeDeckCard({ deck }: { deck: PeopleDeck }) {
  const { currentUserId } = usePrototypeStore();

  const isOwner = deck.ownerId === currentUserId;

  const publishedLabel = useMemo(() => {
    const d = new Date(deck.publishedAt);
    return `Published ${d.toLocaleDateString()} ${d.toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    })}`;
  }, [deck.publishedAt]);

  return (
    <div className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm">
      {/* Header: like MVP PostCard */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-200" />
          <div className="flex flex-col leading-tight">
            <span className="font-medium text-sm">
              {deck.ownerDisplayName}{" "}
              <span className="text-slate-400 font-normal">
                @{deck.ownerHandle}
              </span>
            </span>
            <span className="text-xs text-slate-500">{publishedLabel}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Mode pill */}
          <span className="px-3 py-1 rounded-full border border-slate-200 bg-slate-50 text-[11px] text-slate-700">
            People
          </span>

          {isOwner && (
            <Link
              href="/prototype/rooms/new"
              className="ml-1 rounded-full border border-slate-200 bg-white px-3 py-1 text-[11px] text-slate-700 hover:bg-slate-50"
            >
              Start Room
            </Link>
          )}

          {isOwner && (
            <span className="text-[11px] text-slate-500">
              You own this deck
            </span>
          )}
        </div>
      </div>

      {/* Swipe-style deck viewer (Anchor + 5 lenses) */}
      <PeopleDeckSwipe deck={deck} />
    </div>
  );
}
