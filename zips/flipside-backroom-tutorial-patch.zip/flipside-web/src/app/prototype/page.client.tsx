"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import PeopleDeckSwipeDeck from "@/components/PeopleDeckSwipeDeck";
import { usePrototypeStore } from "@/prototype/people/store";

export default function PrototypeFeedClient() {
  const { seedIfNeeded, peopleDecks, voteOnPost, addReplyToPost, currentUser } =
    usePrototypeStore();

  useEffect(() => {
    seedIfNeeded();
  }, [seedIfNeeded]);

  const decks = useMemo(() => {
    return [...peopleDecks].sort((a, b) => b.createdAt - a.createdAt);
  }, [peopleDecks]);

  const [deckIndex, setDeckIndex] = useState(0);

  useEffect(() => {
    if (deckIndex > 0 && deckIndex >= decks.length) {
      setDeckIndex(Math.max(0, decks.length - 1));
    }
  }, [decks.length, deckIndex]);

  const activeDeck = decks[deckIndex];

  function prevDeck() {
    setDeckIndex((i) => (i > 0 ? i - 1 : i));
  }

  function nextDeck() {
    setDeckIndex((i) => (i < decks.length - 1 ? i + 1 : i));
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center text-xs font-semibold">
            FS
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold tracking-tight">
              Prototype Feed
            </span>
            <span className="text-[10px] text-slate-500">
              People decks (AI not mocked here)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/tutorial"
            className="rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-900"
          >
            Tutorial Home
          </Link>
          <Link
            href="/feed"
            className="rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-900"
          >
            MVP Feed
          </Link>
          <Link
            href="/"
            className="rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-900"
          >
            MVP Add Flip
          </Link>

          <Link
            href="/prototype/create"
            className="inline-flex items-center justify-center rounded-full bg-slate-900 px-4 py-2 text-xs font-medium text-white shadow-sm"
          >
            Add Flip
          </Link>

          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-600">
            <span>{currentUser.name}</span>
            <span className="text-slate-400">@{currentUser.handle}</span>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 py-6 max-w-2xl mx-auto w-full">
        {decks.length === 0 && (
          <div className="rounded-3xl border border-slate-200 bg-white p-6">
            <div className="text-sm font-semibold text-slate-900">
              No People decks yet
            </div>
            <div className="mt-1 text-sm text-slate-600">
              Create one to start testing.
            </div>
            <Link
              href="/prototype/create"
              className="mt-4 inline-flex rounded-full bg-slate-900 px-4 py-2 text-xs font-medium text-white"
            >
              Create People Deck
            </Link>
          </div>
        )}

        {activeDeck && (
          <div className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div className="flex flex-col">
                <div className="text-sm font-semibold text-slate-900">
                  {activeDeck.anchor.author.name}{" "}
                  <span className="text-slate-500 font-medium">
                    @{activeDeck.anchor.author.handle}
                  </span>
                </div>
                <div className="text-xs text-slate-500">
                  Published {new Date(activeDeck.createdAt).toLocaleString()}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="inline-flex items-center rounded-full border border-slate-200 bg-white px-3 py-1 text-xs">
                  People
                </div>

                <div className="hidden sm:flex items-center gap-2 text-[11px] text-slate-500">
                  <button
                    type="button"
                    onClick={prevDeck}
                    disabled={deckIndex === 0}
                    className="px-2 py-1 rounded-full border border-slate-200 disabled:opacity-40"
                    aria-label="Previous deck"
                  >
                    ‹
                  </button>
                  <span>
                    Deck {deckIndex + 1}/{decks.length}
                  </span>
                  <button
                    type="button"
                    onClick={nextDeck}
                    disabled={deckIndex === decks.length - 1}
                    className="px-2 py-1 rounded-full border border-slate-200 disabled:opacity-40"
                    aria-label="Next deck"
                  >
                    ›
                  </button>
                </div>
              </div>
            </div>

            {/* SwipeDeck-like experience inside a People deck */}
            <div className="mt-4">
              <PeopleDeckSwipeDeck
                deck={activeDeck}
                onVote={voteOnPost}
                onReply={addReplyToPost}
              />
            </div>

            {/* Mobile deck pager */}
            {decks.length > 1 && (
              <div className="sm:hidden mt-4 flex items-center justify-center gap-2 text-[11px] text-slate-500">
                <button
                  type="button"
                  onClick={prevDeck}
                  disabled={deckIndex === 0}
                  className="px-2 py-1 rounded-full border border-slate-200 disabled:opacity-40"
                >
                  ‹
                </button>
                <span>
                  Deck {deckIndex + 1}/{decks.length}
                </span>
                <button
                  type="button"
                  onClick={nextDeck}
                  disabled={deckIndex === decks.length - 1}
                  className="px-2 py-1 rounded-full border border-slate-200 disabled:opacity-40"
                >
                  ›
                </button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
