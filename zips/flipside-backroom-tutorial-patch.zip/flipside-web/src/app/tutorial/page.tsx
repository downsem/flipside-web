// src/app/tutorial/page.tsx
"use client";

import Link from "next/link";

export default function TutorialHome() {
  return (
    <div className="min-h-screen bg-slate-50 px-6 py-10">
      <div className="max-w-5xl mx-auto space-y-8">
        <header className="space-y-2">
          <div className="text-xs text-slate-500">Tutorial</div>
          <h1 className="text-3xl font-semibold text-slate-900">
            Explore Flipside (hands-on)
          </h1>
          <p className="text-sm text-slate-600 max-w-3xl">
            This is a clickable tour of the platform. You can move through the MVP,
            People Mode, and Backroom Mode without shipping the real product.
          </p>
        </header>

        <div className="grid gap-6 md:grid-cols-3">
          {/* MVP */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
            <div className="text-xs text-slate-500">MVP</div>
            <div className="text-lg font-semibold text-slate-900">Perspective flips</div>
            <p className="text-sm text-slate-600">
              Create a Flip, then browse the feed and swipe through the five lenses.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <Link
                href="/"
                className="rounded-full bg-slate-900 px-4 py-2 text-sm font-medium text-white"
              >
                Add a Flip
              </Link>
              <Link
                href="/feed"
                className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-900"
              >
                View Feed
              </Link>
            </div>
          </div>

          {/* People Mode */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
            <div className="text-xs text-slate-500">People Mode</div>
            <div className="text-lg font-semibold text-slate-900">Match posts by lens</div>
            <p className="text-sm text-slate-600">
              Curate a deck by selecting which posts best match each lens.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <Link
                href="/prototype/create"
                className="rounded-full bg-slate-900 px-4 py-2 text-sm font-medium text-white"
              >
                Start People Mode
              </Link>
              <Link
                href="/prototype"
                className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-900"
              >
                View People decks
              </Link>
            </div>
          </div>

          {/* Backroom Mode */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm space-y-3">
            <div className="text-xs text-slate-500">Backroom Mode</div>
            <div className="text-lg font-semibold text-slate-900">
              Turn a deck into a Room
            </div>
            <p className="text-sm text-slate-600">
              Walk through a UI-only Room flow (seed + chat → article stub). We preload
              a completed demo deck so you can jump straight into the Room.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <Link
                href="/tutorial/backroom"
                className="rounded-full bg-slate-900 px-4 py-2 text-sm font-medium text-white"
              >
                Start Backroom tutorial
              </Link>
              <Link
                href="/prototype/rooms"
                className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-900"
              >
                View Rooms
              </Link>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="text-sm font-semibold text-slate-900">Tips</div>
          <ul className="mt-3 list-disc pl-5 space-y-1 text-sm text-slate-600">
            <li>
              Use the top nav in tutorial mode to jump between Tutorial Home and the
              real MVP pages.
            </li>
            <li>
              The prototype areas are UI-only and store state in your browser (local
              storage), so refreshing can reset certain demo states.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
