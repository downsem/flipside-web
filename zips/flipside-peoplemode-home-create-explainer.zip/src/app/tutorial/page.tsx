import { redirect } from "next/navigation";

export default function TutorialPage() {
  redirect("/people");
}
