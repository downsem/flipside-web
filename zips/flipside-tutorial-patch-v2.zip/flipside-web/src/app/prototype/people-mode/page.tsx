import PeopleModeBuilderClient from "./page.client";

export const revalidate = 0;

export default function Page() {
  return <PeopleModeBuilderClient />;
}
