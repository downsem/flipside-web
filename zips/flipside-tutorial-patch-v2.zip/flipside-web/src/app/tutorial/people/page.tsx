import PeopleTutorialClient from "./page.client";

export default function PeopleTutorialPage() {
  return <PeopleTutorialClient />;
}
