import BackroomTutorialClient from "./page.client";

export default function BackroomTutorialPage() {
  return <BackroomTutorialClient />;
}
