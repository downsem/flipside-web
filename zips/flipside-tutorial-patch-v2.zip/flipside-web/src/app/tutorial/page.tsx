// src/app/tutorial/page.tsx
import TutorialHubClient from "./page.client";

export default function TutorialHubPage() {
  return <TutorialHubClient />;
}
