import MvpTutorialFeedClient from "./page.client";

export default function MvpTutorialFeedPage() {
  return <MvpTutorialFeedClient />;
}
