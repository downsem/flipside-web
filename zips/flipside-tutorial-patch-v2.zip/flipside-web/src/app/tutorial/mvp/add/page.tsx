import AddMvpTutorialClient from "./page.client";

export default function AddMvpTutorialPage() {
  return <AddMvpTutorialClient />;
}
