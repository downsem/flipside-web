"use client";

import { usePathname } from "next/navigation";
import TutorialNav from "@/components/TutorialNav";

/**
 * Render the prototype/People Mode top bar ONLY on /prototype/* routes.
 * This prevents double-nav on MVP pages like /feed, /post, /share, etc.
 */
export default function PrototypeNavGate() {
  const pathname = usePathname() || "";
  const inPrototype = pathname === "/prototype" || pathname.startsWith("/prototype/");

  if (!inPrototype) return null;
  return <TutorialNav />;
}
