import PeopleHomeClient from "./page.client";

export default function PeopleHomePage() {
  return <PeopleHomeClient />;
}
