"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import {
  activatePeopleMode,
  deactivatePeopleMode,
  isPeopleModeActive,
  onPeopleModeChange,
} from "@/people/mode";

/**
 * A lightweight "mode bar" that appears only when People Mode is active.
 * It gives quick navigation back to People Mode Home, plus MVP shortcuts.
 */
export default function TutorialNav() {
  const pathname = usePathname() || "/";
  const router = useRouter();
  const [active, setActive] = useState(false);

  useEffect(() => {
    setActive(isPeopleModeActive());
    const off = onPeopleModeChange(() => setActive(isPeopleModeActive()));
    return () => off?.();
  }, []);

  // Auto-activate People Mode when user visits People Mode pages.
  useEffect(() => {
    if (pathname.startsWith("/people") || pathname.startsWith("/prototype")) {
      if (!isPeopleModeActive()) activatePeopleMode();
    }
  }, [pathname]);

  if (!active) return null;

  const showHomeBtn = pathname !== "/people";

  function onExit() {
    deactivatePeopleMode();
    // Route users to MVP Feed by default when exiting.
    router.push("/feed");
  }

  return (
    <div className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto max-w-6xl px-4 py-2">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-900">
              People Mode
            </span>
            <span className="text-[11px] text-slate-500">
              (demo sandbox)
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2">
            {showHomeBtn && (
              <Link
                href="/people"
                className="text-xs rounded-full border border-slate-200 bg-white px-3 py-1 hover:bg-slate-50"
              >
                People Mode Home
              </Link>
            )}

            <Link
              href="/feed"
              className="text-xs rounded-full border border-slate-200 bg-white px-3 py-1 hover:bg-slate-50"
            >
              MVP Feed
            </Link>

            <Link
              href="/"
              className="text-xs rounded-full border border-slate-200 bg-white px-3 py-1 hover:bg-slate-50"
            >
              MVP Add Flip
            </Link>

            <button
              type="button"
              onClick={onExit}
              className="text-xs rounded-full bg-slate-900 text-white px-3 py-1 hover:bg-slate-800"
            >
              Exit People Mode
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
