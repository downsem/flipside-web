"use client";

import { useEffect } from "react";

import { PrototypeDeckCard } from "@/components/PrototypeDeckCard";
import { listPublishedDecks, seedIfNeeded } from "@/prototype/people/store";

export default function PrototypeFeedPage() {
  useEffect(() => {
    // Ensure demo data exists for the prototype feed.
    seedIfNeeded();
  }, []);

  const decks = listPublishedDecks();

  return (
    <div className="min-h-screen bg-slate-50 px-6 py-8">
      <div className="mx-auto max-w-3xl space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            Prototype Feed
          </h1>
          <div className="text-sm text-slate-500">
            People decks (AI not mocked here)
          </div>
        </div>

        {decks.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-6 text-slate-600">
            No published decks yet.
          </div>
        ) : (
          <div className="space-y-6">
            {decks.map((deck) => (
              <PrototypeDeckCard key={deck.deckId} deck={deck} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
